#include "CDD_L9388_LLD.h"
#include "CDD_L9388_Cfg.h"

void L9388_Read_CHIPID(void);
bool CDD_L9388_GENCFG_Cfg(void);
bool CDD_L9388_GENCFG2_Cfg(void);
void L9388_Set_PWM(uint16_t PWM_Code);
void L9388_Read_PWM(void);
void L9388_Set_Current(uint16_t Set_Point);
void L9388_Read_Current(void);
void L9388_Set_SOLSERVENA(uint8_t channel);
void L9388_Set_SOLENDR(uint8_t channel, uint8_t mode);
void L9388_Read_SOLSERVENA(void);
void L9388_Read_SOLENDR(void);
void L9388_Read_GENSTATUS(void);
bool CDD_L9388_WDG2STARTTMG_Cfg(void);
bool CDD_L9388_WDG2DELTATMG_Cfg(void);
bool CDD_L9388_WDG2TOUTTMG_Cfg(void);
bool CDD_L9388_WDG2PGM_Cfg(void);
void CDD_L9396_WDG2_Feeding_Service(void);
uint32_t CDD_L9388_Read_ADC(L9388_ADCType ADC_Channel);

#define WDG2_Idle_State 			0xEEU
#define WDG2_FirstSeedReq_State   0x55U
#define WDG2_Write_ANSW_State	    0x88U
#define WDG2_READ_SEED_State	    0xAAU

#define SOLENDR_PWM_MODE 0x0U
#define SOLENDR_FULL_ON_MODE 0x1U
