//L9388 WDG2 Configuration
typedef enum{
    WDG2STARTTMG_VALID_ANSWER_START     = 0xFF,     /*T_Valid_Answ_Start*/
    WDG2STARTTMG_VALID_REQUEST_START    = 0xFF,     /*T_Valid_Req_Start*/
}WDG2STARTTMG_REG_VALUE;

typedef enum{
    WDG2DELTATMG_REQ_CHECK_ENABLE       = 0x1,
    WDG2DELTATMG_VALID_REQUEST_DELTA    = 0x30,
    WDG2DELTATMG_VALID_ANSWER_DELTA     = 0x30,
}WDG2DELTATMG_REG_VALUE;

typedef enum{
    WDG2TOUTTMG_TO_RESET_ENABLE         = 0x1,
    WDG2TOUTTMG_VALID_REQUEST_DELTA     = 0x30,
    WDG2TOUTTMG_VALID_ANSWER_DELTA      = 0x30,
}WDG2TOUTTMG_REG_VALUE;


typedef enum{
    WDG2PGM_WD_RST_EN           = 0x1,
    WDG2PGM_WD_CLK_DIV          = 0x0,
    WDG2PGM_WD_TH_LOW           = 0x7,
    WDG2PGM_WD_TH_HIGH          = 0xF,
    WDG2PGM_WD_CNT_BAD_STEP     = 0x3,
    WDG2PGM_WD_CNT_GOOD_STEP    = 0x1,
}WDG2PGM_REG_VALUE;

typedef enum{
    GENCFG_KA                       = 0x0,
    GENCFG_PHOLD                    = 0x0,
    GENCFG_FS_VDS_TH                = 0x0,
    GENCFG_FS_CMD                   = 0x0,
    GENCFG_FS_EN                    = 0x0,
    GENCFG_PMP_EN                   = 0x0,
    GENCFG_OSC_SPR_SPECT_DIS        = 0x0,
    GENCFG_VDD4_OVC_SD_RESTART_TIME = 0x0,
    GENCFG_VDD4_OVC_FLT_TIME        = 0x0,
    GENCFG_VDD3_OVC_SD_RESTART_TIME = 0x0,
    GENCFG_VDD3_OVC_FLT_TIME        = 0x0,
}GENCFG_REG_VALUE;

typedef enum{
    GENCFG2_FS_VDS_FIL              = 0x0,
    GENCFG2_DIS_TH                  = 0x0,
    GENCFG2_WD_SW_DIS               = 0x0,
    GENCFG2_VDD2_5_AUTO_SWITCH_OFF  = 0x0,
    GENCFG2_VDD1_DIODELOSS_FILT     = 0x0,
    GENCFG2_WD_DIS                  = 0x1,
    GENCFG2_VDD5_DIS                = 0x0,
    GENCFG2_VDD2_DIS                = 0x0,
}GENCFG2_REG_VALUE;