#include "CDD_L9388_Drv.h"
bool CDD_L9388_Init(void);
bool CDD_L9388_WDG2_Init(void);
void CDD_L9388_WDG2_Mainfunction(void);
void CDD_L9388_NO_Ch1_Init_demo(void);