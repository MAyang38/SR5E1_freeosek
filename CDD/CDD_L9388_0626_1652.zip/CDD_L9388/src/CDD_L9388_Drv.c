#include "CDD_L9388_Drv.h"

volatile CDD_L9388_Struct_tag L9388_Tx_Register;
volatile CDD_L9388_Struct_tag L9388_Rx_Register;
extern L9388_Data_tag L9388_SPI_Buffer;

void L9388_Read_CHIPID(void)
{
    L9388_SPI_Buffer.TxOut.B.Addr = CHIPID_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 0;
    L9388_SPI_Buffer.TxOut.B.DATATx = 0;
    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
    L9388_Rx_Register.CHIPID.R = L9388_SPI_Buffer.RxIn.B.DataRx;
}

void L9388_Read_GENSTATUS(void)
{
    L9388_SPI_Buffer.TxOut.B.Addr = GENSTATUS_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 0;
    L9388_SPI_Buffer.TxOut.B.DATATx = 0;
    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
    L9388_Rx_Register.GENSTATUS.R = L9388_SPI_Buffer.RxIn.B.DataRx;
}

bool CDD_L9388_GENCFG_Cfg(void)
{
    bool res = TRUE;
    L9388_SPI_Buffer.TxOut.B.Addr = GENCFG_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 1;

    L9388_Tx_Register.GENCFG.B.KA = GENCFG_KA;
    L9388_Tx_Register.GENCFG.B.PHOLD = GENCFG_PHOLD;
    L9388_Tx_Register.GENCFG.B.FS_VDS_TH = GENCFG_FS_VDS_TH;
    L9388_Tx_Register.GENCFG.B.FS_CMD = GENCFG_FS_CMD;
    L9388_Tx_Register.GENCFG.B.FS_EN = GENCFG_FS_EN;
    L9388_Tx_Register.GENCFG.B.PMP_EN = GENCFG_PMP_EN;
    L9388_Tx_Register.GENCFG.B.OSC_SPR_SPECT_DIS = GENCFG_OSC_SPR_SPECT_DIS;
    L9388_Tx_Register.GENCFG.B.VDD4_OVC_SD_RESTART_TIME = GENCFG_VDD4_OVC_SD_RESTART_TIME;
    L9388_Tx_Register.GENCFG.B.VDD4_OVC_FLT_TIME = GENCFG_VDD4_OVC_FLT_TIME;
    L9388_Tx_Register.GENCFG.B.VDD3_OVC_SD_RESTART_TIME = GENCFG_VDD3_OVC_SD_RESTART_TIME;
    L9388_Tx_Register.GENCFG.B.VDD3_OVC_FLT_TIME = GENCFG_VDD3_OVC_FLT_TIME;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.GENCFG.R;

    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);

    L9388_Rx_Register.GENCFG.R = L9388_SPI_Buffer.RxIn.B.DataRx;

    if((L9388_Rx_Register.GENCFG.B.KA != GENCFG_KA)|| \
    (L9388_Rx_Register.GENCFG.B.PHOLD != GENCFG_PHOLD)|| \
    (L9388_Rx_Register.GENCFG.B.FS_VDS_TH != GENCFG_FS_VDS_TH)|| \
    (L9388_Rx_Register.GENCFG.B.FS_CMD != GENCFG_FS_CMD)|| \
    (L9388_Rx_Register.GENCFG.B.FS_EN != GENCFG_FS_EN)|| \
    (L9388_Rx_Register.GENCFG.B.PMP_EN != GENCFG_PMP_EN)|| \
    (L9388_Rx_Register.GENCFG.B.OSC_SPR_SPECT_DIS != GENCFG_OSC_SPR_SPECT_DIS)|| \
    (L9388_Rx_Register.GENCFG.B.VDD4_OVC_SD_RESTART_TIME != GENCFG_VDD4_OVC_SD_RESTART_TIME)|| \
    (L9388_Rx_Register.GENCFG.B.VDD4_OVC_FLT_TIME != GENCFG_VDD4_OVC_FLT_TIME)|| \
    (L9388_Rx_Register.GENCFG.B.VDD3_OVC_SD_RESTART_TIME != GENCFG_VDD3_OVC_SD_RESTART_TIME)|| \
    (L9388_Rx_Register.GENCFG.B.VDD3_OVC_FLT_TIME != GENCFG_VDD3_OVC_FLT_TIME))
    {
        res = FALSE;
    }
    return res;
}

bool CDD_L9388_GENCFG2_Cfg(void)
{
    bool res = TRUE;
    L9388_SPI_Buffer.TxOut.B.Addr = GENCFG2_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 1;

    L9388_Tx_Register.GENCFG2.B.FS_VDS_FIL = GENCFG2_FS_VDS_FIL;
    L9388_Tx_Register.GENCFG2.B.DIS_TH = GENCFG2_DIS_TH;
    L9388_Tx_Register.GENCFG2.B.WD_SW_DIS = GENCFG2_WD_SW_DIS;
    L9388_Tx_Register.GENCFG2.B.VDD2_5_AUTO_SWITCH_OFF = GENCFG2_VDD2_5_AUTO_SWITCH_OFF;
    L9388_Tx_Register.GENCFG2.B.VDD1_DIODELOSS_FILT = GENCFG2_VDD1_DIODELOSS_FILT;
    L9388_Tx_Register.GENCFG2.B.WD_DIS = GENCFG2_WD_DIS;
    L9388_Tx_Register.GENCFG2.B.VDD5_DIS = GENCFG2_VDD5_DIS;
    L9388_Tx_Register.GENCFG2.B.VDD2_DIS = GENCFG2_VDD2_DIS;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.GENCFG2.R;

    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);

    L9388_Rx_Register.GENCFG2.R = L9388_SPI_Buffer.RxIn.B.DataRx;

    if((L9388_Rx_Register.GENCFG2.B.FS_VDS_FIL != GENCFG2_FS_VDS_FIL)|| \
    (L9388_Rx_Register.GENCFG2.B.DIS_TH != GENCFG2_DIS_TH)|| \
    (L9388_Rx_Register.GENCFG2.B.WD_SW_DIS != GENCFG2_WD_SW_DIS)|| \
    (L9388_Rx_Register.GENCFG2.B.VDD2_5_AUTO_SWITCH_OFF != GENCFG2_VDD2_5_AUTO_SWITCH_OFF)|| \
    (L9388_Rx_Register.GENCFG2.B.VDD1_DIODELOSS_FILT != GENCFG2_VDD1_DIODELOSS_FILT)|| \
    (L9388_Rx_Register.GENCFG2.B.WD_DIS != GENCFG2_WD_DIS)|| \
    (L9388_Rx_Register.GENCFG2.B.VDD5_DIS != GENCFG2_VDD5_DIS)|| \
    (L9388_Rx_Register.GENCFG2.B.VDD2_DIS != GENCFG2_VDD2_DIS))
    {
        res = FALSE;
    }
    return res;
}

void L9388_Set_PWM(uint16_t PWM_Code)
{
    uint16_t SPI_Value;
    if(PWM_Code>16368)
    {
        SPI_Value = 959;
    }
    else if(PWM_Code<1024)
    {
        SPI_Value = 0;
    }else
    {
        SPI_Value = (PWM_Code - 1024)/16;
    }    
    L9388_Tx_Register.CTRLCFG_CHX[0].B.PWM_CODE = SPI_Value;
    L9388_SPI_Buffer.TxOut.B.Addr = CTRLCFG_CH0_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 1;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.CTRLCFG_CHX[0].R;
    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
    L9388_Rx_Register.CTRLCFG_CHX[0].R = L9388_SPI_Buffer.RxIn.B.DataRx;
}

void L9388_Read_PWM(void)
{
    L9388_SPI_Buffer.TxOut.B.Addr = CTRLCFG_CH0_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 0;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.CTRLCFG_CHX[0].R;
    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
    L9388_Rx_Register.CTRLCFG_CHX[0].R = L9388_SPI_Buffer.RxIn.B.DataRx;  
}

void L9388_Set_Current(uint16_t Set_Point)
{
    uint16_t SPI_Value;
    if(Set_Point>3071)
    {
        SPI_Value = 2047;
    }
    else
    {
        SPI_Value = (uint16_t)(((uint32_t)Set_Point)*2047/3070);
    }
    
    L9388_Tx_Register.SETPOINT_CHX[0].B.SET_POINT = SPI_Value;
    L9388_SPI_Buffer.TxOut.B.Addr = SETPOINT_CH0_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 1;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.SETPOINT_CHX[0].R;
    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
    L9388_Rx_Register.SETPOINT_CHX[0].R = L9388_SPI_Buffer.RxIn.B.DataRx;
}

void L9388_Read_Current(void)
{
    L9388_SPI_Buffer.TxOut.B.Addr = SETPOINT_CH0_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 0;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.SETPOINT_CHX[0].R;
    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
    L9388_Rx_Register.SETPOINT_CHX[0].R = L9388_SPI_Buffer.RxIn.B.DataRx;
}

void L9388_Set_SOLSERVENA(uint8_t channel)
{
    L9388_Tx_Register.SOLSERVENA.R |= (1<<channel) ;
	L9388_SPI_Buffer.TxOut.B.Addr = SOLSERVENA_ADDR;
	L9388_SPI_Buffer.TxOut.B.WRn = 1;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.SOLSERVENA.R;
	L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
	L9388_Rx_Register.SOLSERVENA.R = L9388_SPI_Buffer.RxIn.B.DataRx;
}

void L9388_Read_SOLSERVENA(void)
{
	L9388_SPI_Buffer.TxOut.B.Addr = SOLSERVENA_ADDR;
	L9388_SPI_Buffer.TxOut.B.WRn = 0;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.SOLSERVENA.R;
	L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
	L9388_Rx_Register.SOLSERVENA.R = L9388_SPI_Buffer.RxIn.B.DataRx;
}

void L9388_Set_SOLENDR(uint8_t channel, uint8_t mode)
{
    if(mode == SOLENDR_PWM_MODE)
    {
        L9388_Tx_Register.SOLENDR.R |= (1<<(channel*2+1));
        L9388_Tx_Register.SOLENDR.R &= ~(1<<channel*2);      
    }
    else if(mode == SOLENDR_FULL_ON_MODE)
    {
        L9388_Tx_Register.SOLENDR.R |= (1<<(channel*2+1));
        L9388_Tx_Register.SOLENDR.R |= (1<<channel*2);
    }
	L9388_SPI_Buffer.TxOut.B.Addr = SOLENDR_ADDR;
	L9388_SPI_Buffer.TxOut.B.WRn = 1;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.SOLENDR.R;
	L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
	L9388_Rx_Register.SOLENDR.R = L9388_SPI_Buffer.RxIn.B.DataRx;
}

void L9388_Read_SOLENDR(void)
{
	L9388_SPI_Buffer.TxOut.B.Addr = SOLENDR_ADDR;
	L9388_SPI_Buffer.TxOut.B.WRn = 0;
    L9388_SPI_Buffer.TxOut.B.DATATx = 0;
	L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
	L9388_Rx_Register.SOLENDR.R = L9388_SPI_Buffer.RxIn.B.DataRx;
}

/*WDG2*/
void L9388_WD2_Read_WDG2STATUS(void)
{
    L9388_SPI_Buffer.TxOut.B.Addr = WDG2STATUS_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 0;
    L9388_SPI_Buffer.TxOut.B.DATATx = 0;
    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
    L9388_Rx_Register.WDG2STATUS.R = L9388_SPI_Buffer.RxIn.B.DataRx;
}

void L9388_WD2_Read_Seed(void)
{
    L9388_SPI_Buffer.TxOut.B.Addr = WDG2SEED_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 1;
    L9388_SPI_Buffer.TxOut.B.DATATx = 0;
    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);
    L9388_Rx_Register.WDG2SEED.R = L9388_SPI_Buffer.RxIn.B.DataRx;
}

void L9388_WD2_Write_Answer(void)
{
    L9388_SPI_Buffer.TxOut.B.Addr = WDG2ANS_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 1;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.WDG2ANS.R;
    L9388_SPI_WRDataWithCRC(&L9388_SPI_Buffer);
}

uint8_t Seed_Buffer[32];
uint8_t Ans_Buffer[32];
uint8_t cnt = 0;
uint8_t WDG2_StateCtrl = WDG2_READ_SEED_State;
void CDD_L9396_WDG2_Feeding_Service(void)
{
	if(WDG2_StateCtrl == WDG2_Write_ANSW_State ){
        L9388_WD2_Write_Answer();		
        if(L9388_Rx_Register.WDG2STATUS.B.WD_BAD_ANSW == 0)
        {
            L9388_WD2_Read_WDG2STATUS();
        } 
		WDG2_StateCtrl = WDG2_READ_SEED_State;  /*change to read seed state*/
	}
	else if(WDG2_StateCtrl == WDG2_READ_SEED_State)
	{
        L9388_WD2_Read_Seed(); /*Read Seed */
        L9388_Tx_Register.WDG2ANS.B.ANSWER_HIGH = L9388_Rx_Register.WDG2SEED.B.SEED;    // ans_hi
        L9388_Tx_Register.WDG2ANS.B.ANSWER_LOW = (L9388_Rx_Register.WDG2SEED.B.SEED^0xFFU)+1; //ans_low  

		#if 1 /*Load Answs and Seeds for monitoring */
		cnt++;
		if(cnt >= 32)		cnt = 0;
		Seed_Buffer[cnt] = L9388_Rx_Register.WDG2SEED.B.SEED;
		Ans_Buffer[cnt] = L9388_Tx_Register.WDG2ANS.B.ANSWER_LOW;
		#endif

		WDG2_StateCtrl = WDG2_Write_ANSW_State; /*Next loop : Write Answ*/
	}
	else{
		/*Err*/
		WDG2_StateCtrl = WDG2_Idle_State;
	}

}

bool CDD_L9388_WDG2STARTTMG_Cfg(void)
{
    bool res = TRUE;
    L9388_SPI_Buffer.TxOut.B.Addr = WDG2STARTTMG_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 1;

    L9388_Tx_Register.WDG2STARTTMG.B.VALID_ANSWER_START = WDG2STARTTMG_VALID_ANSWER_START;
    L9388_Tx_Register.WDG2STARTTMG.B.VALID_REQUEST_START = WDG2STARTTMG_VALID_REQUEST_START;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.WDG2STARTTMG.R;

    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);

    L9388_Rx_Register.WDG2STARTTMG.R = L9388_SPI_Buffer.RxIn.B.DataRx;

    if((L9388_Rx_Register.WDG2STARTTMG.B.VALID_ANSWER_START != WDG2STARTTMG_VALID_ANSWER_START)|| \
    (L9388_Rx_Register.WDG2STARTTMG.B.VALID_ANSWER_START != WDG2STARTTMG_VALID_ANSWER_START))
    {
        res = FALSE;
    }
    return res;
}

bool CDD_L9388_WDG2DELTATMG_Cfg(void)
{
    bool res = TRUE;
    L9388_SPI_Buffer.TxOut.B.Addr = WDG2DELTATMG_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 1;

    L9388_Tx_Register.WDG2DELTATMG.B.REQ_CHECK_ENABLE = WDG2DELTATMG_REQ_CHECK_ENABLE;
    L9388_Tx_Register.WDG2DELTATMG.B.VALID_REQUEST_DELTA = WDG2DELTATMG_VALID_REQUEST_DELTA;
    L9388_Tx_Register.WDG2DELTATMG.B.VALID_ANSWER_DELTA = WDG2DELTATMG_VALID_ANSWER_DELTA;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.WDG2DELTATMG.R;

    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);

    L9388_Rx_Register.WDG2DELTATMG.R = L9388_SPI_Buffer.RxIn.B.DataRx;

    if((L9388_Rx_Register.WDG2DELTATMG.B.REQ_CHECK_ENABLE != WDG2DELTATMG_REQ_CHECK_ENABLE)|| \
    (L9388_Rx_Register.WDG2DELTATMG.B.VALID_REQUEST_DELTA != WDG2DELTATMG_VALID_REQUEST_DELTA)|| \
    (L9388_Rx_Register.WDG2DELTATMG.B.VALID_ANSWER_DELTA != WDG2DELTATMG_VALID_ANSWER_DELTA))
    {
        res = FALSE;
    }
    return res; 
}

bool CDD_L9388_WDG2TOUTTMG_Cfg(void)
{
    bool res = TRUE;
    L9388_SPI_Buffer.TxOut.B.Addr = WDG2TOUTTMG_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 1;

    L9388_Tx_Register.WDG2TOUTTMG.B.TO_RESET_ENABLE = WDG2TOUTTMG_TO_RESET_ENABLE;
    L9388_Tx_Register.WDG2TOUTTMG.B.REQUEST_TIME_OUT_DELTA = WDG2TOUTTMG_VALID_REQUEST_DELTA;
    L9388_Tx_Register.WDG2TOUTTMG.B.ANSWER_TIME_OUT_DELTA = WDG2TOUTTMG_VALID_ANSWER_DELTA;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.WDG2TOUTTMG.R;

    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);

    L9388_Rx_Register.WDG2TOUTTMG.R = L9388_SPI_Buffer.RxIn.B.DataRx;

    if((L9388_Rx_Register.WDG2TOUTTMG.B.TO_RESET_ENABLE != WDG2TOUTTMG_TO_RESET_ENABLE)|| \
    (L9388_Rx_Register.WDG2TOUTTMG.B.REQUEST_TIME_OUT_DELTA != WDG2TOUTTMG_VALID_REQUEST_DELTA)|| \
    (L9388_Rx_Register.WDG2TOUTTMG.B.ANSWER_TIME_OUT_DELTA != WDG2TOUTTMG_VALID_ANSWER_DELTA))
    {
        res = FALSE;
    }
    return res;     
}

bool CDD_L9388_WDG2PGM_Cfg(void)
{
    bool res = TRUE;
    L9388_SPI_Buffer.TxOut.B.Addr = WDG2PGM_ADDR;
    L9388_SPI_Buffer.TxOut.B.WRn = 1;

    L9388_Tx_Register.WDG2PGM.B.RESET_ENABLE = WDG2PGM_WD_RST_EN;
    L9388_Tx_Register.WDG2PGM.B.CLOCK_DIVISION = WDG2PGM_WD_CLK_DIV;
    L9388_Tx_Register.WDG2PGM.B.LOW_TH = WDG2PGM_WD_TH_LOW;
    L9388_Tx_Register.WDG2PGM.B.HIGH_TH = WDG2PGM_WD_TH_HIGH;
    L9388_Tx_Register.WDG2PGM.B.BAD_STEPS = WDG2PGM_WD_CNT_BAD_STEP;
    L9388_Tx_Register.WDG2PGM.B.GOOD_STEPS = WDG2PGM_WD_CNT_GOOD_STEP;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.WDG2PGM.R;

    L9388_SPI_ExchangeDataWithCRC(&L9388_SPI_Buffer);

    L9388_Rx_Register.WDG2PGM.R = L9388_SPI_Buffer.RxIn.B.DataRx;

    if((L9388_Rx_Register.WDG2PGM.B.RESET_ENABLE != WDG2PGM_WD_RST_EN)|| \
    (L9388_Rx_Register.WDG2PGM.B.CLOCK_DIVISION != WDG2PGM_WD_CLK_DIV)|| \
    (L9388_Rx_Register.WDG2PGM.B.LOW_TH != WDG2PGM_WD_TH_LOW)|| \
    (L9388_Rx_Register.WDG2PGM.B.HIGH_TH != WDG2PGM_WD_TH_HIGH)|| \
    (L9388_Rx_Register.WDG2PGM.B.BAD_STEPS != WDG2PGM_WD_CNT_BAD_STEP)|| \
    (L9388_Rx_Register.WDG2PGM.B.GOOD_STEPS != WDG2PGM_WD_CNT_GOOD_STEP))
    {
        res = FALSE;
    }
    return res; 
}

uint32_t CDD_L9388_Read_ADC(L9388_ADCType ADC_Channel)
{
	uint32_t temp_ADC_initial=0;
	uint32_t temp_ADC_digital=0;
	uint32_t temp_ADC_physical=0;
    uint8_t counter = 0;
    L9388_Tx_Register.ADC_DR.R = 0;
    L9388_Tx_Register.ADC_DR.B.ADC_SEL = ADC_Channel;

    L9388_SPI_Buffer.TxOut.B.WRn = 1;
    L9388_SPI_Buffer.TxOut.B.Addr = ADC_DR_ADDR;
    L9388_SPI_Buffer.TxOut.B.DATATx = L9388_Tx_Register.ADC_DR.R;
    
    L9388_SPI_WRDataWithCRC(&L9388_SPI_Buffer);

    do
    {
        osal_delay_millisec(1U);
        L9388_SPI_RDDataWithCRC(&L9388_SPI_Buffer);
        L9388_Rx_Register.ADC_DR.R = L9388_SPI_Buffer.RxIn.B.DataRx;
        counter++;
    }while ((!L9388_Rx_Register.ADC_DR.B.ADC_BUSY)&&(counter<10));
   
    if(counter>10)
    {
        return 0;
    }
    
	temp_ADC_initial= (uint32_t)(L9388_Rx_Register.ADC_DR.B.ADC_DATA_OUT); /*load MISO data*/

	// if(ADCType%2==0)
	// 	temp_ADC_digital=temp_ADC_initial&0x03FF;
	// else
	// 	temp_ADC_digital=temp_ADC_initial>>10;
	switch(ADC_Channel)
		{
			case	ADC_ADCIN1_SEL_ADDR:temp_ADC_physical=temp_ADC_initial*2500/1023;break;
			case	ADC_ADCIN2_SEL_ADDR:temp_ADC_physical=temp_ADC_initial*2500/1023;break;
			case	ADC_ADCIN3_SEL_ADDR:temp_ADC_physical=temp_ADC_initial*2500/1023;break;
			case	ADC_ADCIN4_SEL_ADDR:temp_ADC_physical=temp_ADC_initial*2500/1023;break;
			case	ADC_WS1_SEL_ADDR:temp_ADC_physical=temp_ADC_digital*13.2*2500/1023;break;
			case	ADC_WS2_SEL_ADDR:temp_ADC_physical=temp_ADC_digital*13.2*2500/1023;break;
			case	ADC_WS3_SEL_ADDR:temp_ADC_physical=temp_ADC_digital*13.2*2500/1023;break;
			case	ADC_WS4_SEL_ADDR:temp_ADC_physical=temp_ADC_digital*13.2*2500/1023;break;
			case	ADC_VDD2_SEL_ADDR:temp_ADC_physical=temp_ADC_digital*4.42*2500/1023;break;
			case	ADC_VDD3_SEL_ADDR:temp_ADC_physical=temp_ADC_digital*4.42*2500/1023;break;
			case	ADC_VDD4_SEL_ADDR:temp_ADC_physical=temp_ADC_digital*4.42*2500/1023;break;
			case	ADC_VDD5_SEL_ADDR:temp_ADC_physical=temp_ADC_digital*4.42*2500/1023;break;
			case	ADC_VPWR_SEL_ADDR:temp_ADC_physical=temp_ADC_digital*32*2500/1023;break;
			case	ADC_FSD_SEL_ADDR:temp_ADC_physical=temp_ADC_digital*32*2500/1023;break;
			default: break;
		}
	return temp_ADC_physical;
}
