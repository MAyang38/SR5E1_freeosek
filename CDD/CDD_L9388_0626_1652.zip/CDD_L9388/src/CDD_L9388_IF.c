#include "CDD_L9388_IF.h"

bool CDD_L9388_Init(void)
{
    L9388_Read_CHIPID();
    L9388_Read_GENSTATUS();
    if(!CDD_L9388_GENCFG_Cfg())
    {
        return FALSE;
    }
    else if(!CDD_L9388_GENCFG2_Cfg())
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

bool CDD_L9388_WDG2_Init(void)
{
    if(!CDD_L9388_WDG2STARTTMG_Cfg())
    {
        return FALSE;
    }
    else if(!CDD_L9388_WDG2DELTATMG_Cfg())
    {
        return FALSE;
    }
    else if(!CDD_L9388_WDG2TOUTTMG_Cfg())
    {
        return FALSE;
    }
    else if(!CDD_L9388_WDG2PGM_Cfg())
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

void CDD_L9388_WDG2_Mainfunction(void)
{
    CDD_L9396_WDG2_Feeding_Service();
}

uint8_t channel = 0;
uint8_t mode = SOLENDR_PWM_MODE;
void CDD_L9388_NO_Ch1_Init_demo(void)
{
    L9388_Set_PWM(10000);
    L9388_Set_Current(100);
    L9388_Set_SOLSERVENA(channel);
    L9388_Set_SOLENDR(channel,mode);
}

uint32_t CDD_L9388_ReadADVoltage(L9388_ADCType ADC_Channel)
{   
    uint32_t ADC_Value = 0;
    ADC_Value = CDD_L9388_Read_ADC(ADC_Channel);
    return ADC_Value;
}